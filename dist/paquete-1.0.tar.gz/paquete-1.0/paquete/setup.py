from setuptools import setup

setup(
    name="paquete",
    version= "1.0",
    description= "paquete redistribuible para la 2da pre entrega",
    author= "Ruiz Marcelo",
    author_email= "serviplay82@gmail.com",

    packages=["paquete"]


)